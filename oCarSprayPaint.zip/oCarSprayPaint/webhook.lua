ConfigWebhook = {

    Anticheat = "", -- permet de dectecter une utilisation frauduleuse 
    UsePeinture = "", -- permet de voir qui utilise une bombe de peinture

}